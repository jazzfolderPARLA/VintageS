// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments
// fm1backup.js against a simulated device: 7-bit packing, CRC, manifest checks, a full capture,
// validation before the first write, restore order (live music last) and abort on a failed chunk.
import { BACKUP_IDS, BACKUP_CMD, bkU32, bkR32, bkPack, bkUnpack, bkCrc, bkManifest, readBackup, captureBackup, restoreBackup } from "./fm1backup.js";

let fails = 0;
const ok = (c, what) => { console.log(`${what.padEnd(72)} ${c ? "ok" : "FAIL"}`); if (!c) fails++; };
const throws = (f) => { try { f(); return false; } catch { return true; } };
const athrows = async (f) => { try { await f(); return false; } catch { return true; } };

const rnd = (n, seed) => Uint8Array.from({ length: n }, (_, i) => (i * 131 + seed * 17 + (i >> 3)) & 255);
ok(bkR32(bkU32(0xdeadbeef)) === 0xdeadbeef && bkCrc(new TextEncoder().encode("123456789")) === 0xcbf43926, "backup: numbers and CRC-32");
const b = rnd(1000, 1);
ok(bkUnpack(bkPack(b), b.length).every((v, i) => v === b[i]), "backup: 7-bit pack / unpack round trip");
ok(throws(() => bkUnpack([...bkPack(b.subarray(0, 14)), 0], 14)), "backup: trailing bytes refused");

/* a device: objects by id, sample slots, the order of writes */
function device(objs, opt = {}) {
  const d = { objs: new Map(objs), log: [], staged: null };
  const ids = opt.ids || BACKUP_IDS;
  if (!d.objs.has(0)) d.objs.set(0, rnd(opt.runtimeSize || 20224, 9));
  d.request = async ([cmd, a]) => {
    if (cmd === BACKUP_CMD.LIST) {
      const out = [1, 0, ids.length];
      for (const id of ids) { const v = d.objs.get(id) || new Uint8Array(0); out.push(id, ...bkU32(v.length), ...bkU32(v.length ? bkCrc(v) : 0)); }
      return out;
    }
    if (cmd === BACKUP_CMD.GET) {
      const id = a[0], off = bkR32(a, 1), n = a[6] | a[7] << 7, v = d.objs.get(id);
      if (opt.changeOnGet === id && off === 0) v[0] ^= 1;
      return [id, 0, ...bkU32(off), n & 127, n >> 7, ...bkPack(v.subarray(off, off + n))];
    }
    if (cmd === BACKUP_CMD.PUT) {
      const [op, id] = a;
      if (op === 0) { const size = bkR32(a, 2), rc = opt.refuse?.(id, size) || 0; if (!rc) d.staged = { id, size, crc: bkR32(a, 7), bytes: [], chunks: 0 }; return [op, id, rc]; }
      if (op === 1) {
        d.staged.chunks++;
        if (opt.failChunk === id) return [op, id, 2];
        const off = bkR32(a, 2), p = a.slice(7), n = Math.min(256, d.staged.size - off);
        d.staged.bytes.push(...bkUnpack(p, n)); return [op, id, 0];
      }
      if (op === 2) { const s = Uint8Array.from(d.staged.bytes); const rc = bkCrc(s) === d.staged.crc ? 0 : 2; if (!rc) { d.objs.set(id, s); d.log.push(id); } return [op, id, rc]; }
      if (op === 3) { if (d.staged?.chunks) d.log.push(`abort ${id}`); return [op, id, 0]; }  /* (a preflight: no chunks) */
    }
    if (cmd === 11 || cmd === 12 || cmd === 13 || cmd === 14) { if (cmd === 13 || cmd === 14) d.log.push(32 + a[0]); return [a[0], 0]; }
    throw new Error(`unexpected ${cmd}`);
  };
  return d;
}
const objs = [[0, rnd(3388, 2)], [1, rnd(1200, 3)], [2, rnd(3388, 4)], [6, rnd(3080, 5)]];
const dev = device(objs);
const file = await captureBackup(dev.request, "TEST");
ok(file.objects.length === BACKUP_IDS.length && file.objects[0].size === 3388 && file.objects[3].size === 0, "backup: capture lists every object, empty ones as 0");
ok(readBackup(JSON.stringify(file)).objects[2].bytes.every((v, i) => v === objs[2][1][i]), "backup: capture -> file -> bytes round trip");
ok(await athrows(() => captureBackup(device(objs.map(([i, v]) => [i, v.slice()]), { changeOnGet: 2 }).request, "TEST")), "backup: a device that changes during capture fails the capture");

const bad = JSON.parse(JSON.stringify(file)); bad.objects[2].crc ^= 1;
ok(throws(() => readBackup(bad)), "backup: a damaged file is refused");
const noRun = JSON.parse(JSON.stringify(file)); noRun.objects[0] = { ...noRun.objects[0], size: 0, crc: 0, data: "" };
ok(throws(() => readBackup(noRun)), "backup: a file without the current music is refused");
ok(throws(() => bkManifest([1, 0, 3])), "backup: a short manifest is refused");

const target = device([]);
const damaged = JSON.parse(JSON.stringify(file)); damaged.objects[6].crc ^= 1;
ok(await athrows(() => restoreBackup(target.request, damaged)) && target.log.length === 0, "backup: restore validates every byte before the first write");
await restoreBackup(target.request, file);
const order = target.log.filter((x) => typeof x === "number");
ok(order.at(-1) === 0 && order.at(-2) === 1 && order.indexOf(2) < order.indexOf(1), "backup: restore order: projects, banks, samples, settings, live music last");
ok([0, 1, 2, 6].every((id) => target.objs.get(id).every((v, i) => v === objs.find((o) => o[0] === id)[1][i])), "backup: restored objects equal the source");
{   /* the FM6 patch bank (id 8) and the archives of firmware before it (11 objects, no id 8) */
  ok(BACKUP_IDS.includes(8) && file.objects.some((o) => o.id === 8), "backup: the FM6 bank (id 8) is part of the archive");
  const old = JSON.parse(JSON.stringify(file)); old.objects = old.objects.filter((o) => o.id !== 8);
  ok(readBackup(old).objects.length === 11, "backup: an archive of the 11 objects before FM6 still reads");
  const odd = JSON.parse(JSON.stringify(file)); odd.objects = odd.objects.filter((o) => o.id !== 33);
  ok(throws(() => readBackup(odd)), "backup: an archive missing another object is refused");
}
const failing = device([], { failChunk: 2 });
ok(await athrows(() => restoreBackup(failing.request, file)) && failing.log.includes("abort 2") && !failing.log.includes(0), "backup: a refused chunk aborts that object and stops before the live music");

const bankIds = BACKUP_IDS.filter(id => id < 32);
const bankObjects = [[0, rnd(20224, 10)], [1, rnd(1200, 11)], [2, rnd(20224, 12)]];
const bankFile = await captureBackup(device(bankObjects, { ids: bankIds }).request, "BANKS");
ok(readBackup(bankFile).objects.length === 9 && bankFile.objects[2].size === 20224,
  "backup: captures all nine bank-era objects, including full saved banks");
const bankTarget = device([], { ids: bankIds });
await restoreBackup(bankTarget.request, bankFile);
ok(bankTarget.log.at(-1) === 0 && bankTarget.objs.get(2).every((v, i) => v === bankObjects[2][1][i]),
  "backup: full bank archive restores with current music last");
const legacyTarget = device([], { runtimeSize: 3584 });
ok(await athrows(() => restoreBackup(legacyTarget.request, bankFile)) && !legacyTarget.log.length,
  "backup: bank archive is refused by older firmware before any write");
const migratedTarget = device([], { ids: bankIds });
await restoreBackup(migratedTarget.request, file);
ok(!migratedTarget.log.some(id => id >= 32) && migratedTarget.objs.get(0).length === 3388,
  "backup: legacy archive without samples migrates, skipping retired empty slots");
const sample = new Uint8Array(514), sampleView = new DataView(sample.buffer);
sampleView.setUint32(0, 0x504d5346, true); sampleView.setUint16(4, 1, true); sample[6] = 1;
sampleView.setUint32(16, 2, true); sampleView.setUint32(20, bkCrc(sample.subarray(512)), true);
sampleView.setUint32(36, 4, true); sampleView.setUint32(44, 3, true); sampleView.setUint32(48, 22050, true);
const sampleFile = await captureBackup(device([...objs, [32, sample]]).request, "LEGACY");
const noSampleTarget = device([], { ids: bankIds });
ok(await athrows(() => restoreBackup(noSampleTarget.request, sampleFile)) && !noSampleTarget.log.length,
  "backup: nonempty retired sample slots are refused before any write");

const czIds = Array.from({length:17},(_,i)=>i);
const czBank = new Uint8Array(2332), czView = new DataView(czBank.buffer);
czView.setUint32(0,0x42435a43,true);czView.setUint16(4,1,true);czView.setUint16(6,16,true);czView.setUint32(8,1,true);
czBank.set(new TextEncoder().encode("MY CZ BANK"),12);czBank[28+128]=65;
const czFile=await captureBackup(device([...bankObjects,[9,czBank],[16,czBank.slice()]],{ids:czIds}).request,"CZ BANKS");
ok(readBackup(czFile).objects.length===17,"backup: captures all eight dedicated CZ banks");
const czTarget=device([],{ids:czIds});await restoreBackup(czTarget.request,czFile);
ok(czTarget.log.at(-1)===0 && [9,16].every(id=>czTarget.objs.get(id).every((x,i)=>x===czBank[i])),"backup: native CZ banks restore byte-exact with live music last");
const nextBackup=JSON.parse(JSON.stringify(bankFile));nextBackup.objects[0].size=19092;const nextRaw=rnd(19092,14);nextBackup.objects[0].crc=bkCrc(nextRaw);nextBackup.objects[0].data=Buffer.from(nextRaw).toString("base64");
const nextTarget=device([],{ids:czIds,runtimeSize:19008});await restoreBackup(nextTarget.request,nextBackup);
ok(nextTarget.log.at(-1)===0,"backup: previous next CZ bank format reaches firmware migration");
const badBank=JSON.parse(JSON.stringify(czFile));const broken=czBank.slice();broken[0]^=1;
badBank.objects[9]={...badBank.objects[9],crc:bkCrc(broken),data:Buffer.from(broken).toString("base64")};
const protectedTarget=device([],{ids:czIds});
ok(await athrows(()=>restoreBackup(protectedTarget.request,badBank)) && !protectedTarget.log.length,"backup: corrupt CZ bank refused before any writes");
const oldToCz=device([[9,czBank]],{ids:czIds});await restoreBackup(oldToCz.request,bankFile);
ok(!oldToCz.log.includes(9) && oldToCz.objs.get(9)===czBank,"backup: older archives preserve dedicated CZ banks absent from archive");

const largeObjects=[[0,rnd(27200,20)],[1,rnd(1200,21)],[2,rnd(27200,22)]];
// The ownership backport appends user-record and voice objects after the CZ banks.
const ownedIds=Array.from({length:21},(_,i)=>i);
const ownedData=[[17,rnd(3816,20)],[18,rnd(3816,21)],[19,rnd(3728,22)],[20,rnd(3728,23)]];
const ownedFile=await captureBackup(device([...bankObjects,...ownedData],{ids:ownedIds}).request,"OWNED FM6");
const ownedTarget=device([],{ids:ownedIds});await restoreBackup(ownedTarget.request,ownedFile);
ok(readBackup(ownedFile).objects.length===21 && ownedData.every(([id,bytes])=>ownedTarget.objs.get(id).every((v,i)=>v===bytes[i])),"backup: all 64 preset records and their owned FM6 voices round trip");
ok(ownedTarget.log.at(-1)===0 && ownedTarget.log.indexOf(18)<ownedTarget.log.indexOf(20),"backup: user records restore before their voices, live music last");
const largeFile=await captureBackup(device(largeObjects,{ids:czIds,runtimeSize:27200}).request,"1024 NOTES");
const largeTarget=device([],{ids:czIds,runtimeSize:27200});await restoreBackup(largeTarget.request,largeFile);
ok(largeTarget.objs.get(2).every((v,i)=>v===largeObjects[2][1][i]),"backup: expanded 1024-note projects capture and restore completely");
const smallTarget=device([],{ids:czIds,runtimeSize:20224});
ok(await athrows(()=>restoreBackup(smallTarget.request,largeFile)) && !smallTarget.log.length,"backup: expanded archives are refused by 152-note firmware before any write");
const mixed=JSON.parse(JSON.stringify(largeFile));mixed.objects[0]=bankFile.objects[0];
const mixedTarget=device([],{ids:czIds,runtimeSize:20224});
ok(await athrows(()=>restoreBackup(mixedTarget.request,mixed)) && !mixedTarget.log.length,"backup: preflight checks saved slots too when runtime is an older format");

const nativeIds=Array.from({length:23},(_,i)=>i),nativeFM=new Uint8Array(2060),nv=new DataView(nativeFM.buffer);
nv.setUint32(0,0x314d464e,true);nv.setUint16(4,1,true);nv.setUint16(6,16,true);nv.setUint32(8,0x8001,true);
for(const slot of [0,15])for(let i=0;i<128;i++)nativeFM[12+slot*128+i]=(i*17+slot)&127;
const nativeCZ=czBank.slice();new DataView(nativeCZ.buffer).setUint16(4,2,true);
const nativeObjects=[[9,nativeCZ],...[19,20,21,22].map(id=>[id,nativeFM.slice()])];
const nativeFile=await captureBackup(device([...bankObjects,...nativeObjects],{ids:nativeIds}).request,"NATIVE PRESETS");
const nativeTarget=device([],{ids:nativeIds});await restoreBackup(nativeTarget.request,nativeFile);
ok(readBackup(nativeFile).objects.length===23 && nativeObjects.every(([id,bytes])=>nativeTarget.objs.get(id).every((v,i)=>v===bytes[i])),"backup: independent native FM6/CZ pools round trip in 23-object archive");
const badNative=JSON.parse(JSON.stringify(nativeFile)),invalidFM=nativeFM.slice();invalidFM[12]=128;
badNative.objects[21]={...badNative.objects[21],crc:bkCrc(invalidFM),data:Buffer.from(invalidFM).toString("base64")};
const nativeProtected=device([],{ids:nativeIds});
ok(await athrows(()=>restoreBackup(nativeProtected.request,badNative)) && !nativeProtected.log.length,"backup: malformed native voice refused before any restore writes");
const oldOwnedTarget=device([],{ids:nativeIds,refuse:(id,size)=>id>=19&&id<=22&&size!==2060?1:0});
ok(await athrows(()=>restoreBackup(oldOwnedTarget.request,ownedFile)) && !oldOwnedTarget.log.length,"backup: an archive the firmware refuses (old owned voices) writes nothing");

console.log(fails ? `BACKUP WEB TESTS FAILED (${fails})` : "backup web tests passed");
process.exit(fails ? 1 : 0);
